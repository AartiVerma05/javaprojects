package com.cognizant.dao;

import java.util.List;

import com.cognizant.entity.Product;

public interface ProductDAO {
	
//	public void showProduct(int productId);
	public boolean addProduct(Product product);
	public boolean checkProduct(int productId);
	public List<Product> viewProduct();

}

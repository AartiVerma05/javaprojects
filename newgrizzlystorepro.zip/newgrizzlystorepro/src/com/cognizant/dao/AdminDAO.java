package com.cognizant.dao;

public interface AdminDAO {
	
	

	public boolean authAdmin(String username, String password);
	//public int getCount(String username);
	public int getStatus(String username);
	public void changeStatus(String username);

}

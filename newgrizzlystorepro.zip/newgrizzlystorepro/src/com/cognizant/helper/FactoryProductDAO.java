package com.cognizant.helper;



import com.cognizant.dao.JDBCProductDAOImpl;
import com.cognizant.dao.ProductDAO;

public class FactoryProductDAO {
	public static ProductDAO createProductDAO() {
		// TODO Auto-generated method stub
		ProductDAO adminDAO=new JDBCProductDAOImpl();
		return adminDAO;
	}

}
